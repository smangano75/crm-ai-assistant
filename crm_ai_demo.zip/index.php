
<?php
// index.php - Demo semplice di integrazione AI in un mini-CRM

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $prompt = $_POST['prompt'] ?? '';
    $response = askAI($prompt);
} else {
    $response = '';
}

function askAI($prompt) {
    // Simulazione di risposta AI (in produzione si userebbe l'API di OpenAI)
    if (stripos($prompt, 'clienti attivi') !== false) {
        return "Hai 12 clienti attivi. Vuoi visualizzarli in dettaglio?";
    } elseif (stripos($prompt, 'follow-up') !== false) {
        return "Ecco un esempio di email: 'Gentile cliente, la contattiamo per un aggiornamento...'.";
    } else {
        return "Non ho capito la richiesta. Puoi riformularla?";
    }
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>CRM Assistant AI</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 2rem; }
        .box { max-width: 600px; margin: auto; }
        textarea { width: 100%; height: 100px; margin-bottom: 1rem; }
        .response { background: #f4f4f4; padding: 1rem; border-radius: 5px; }
    </style>
</head>
<body>
    <div class="box">
        <h2>Assistente AI per CRM</h2>
        <form method="post">
            <label for="prompt">Scrivi una richiesta (es: "Mostrami i clienti attivi"):</label><br>
            <textarea name="prompt" id="prompt" required><?= htmlspecialchars($_POST['prompt'] ?? '') ?></textarea><br>
            <button type="submit">Invia</button>
        </form>
        <?php if ($response): ?>
            <div class="response">
                <strong>Risposta AI:</strong><br>
                <?= htmlspecialchars($response) ?>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
