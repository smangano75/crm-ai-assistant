
# CRM Assistant AI (Demo in PHP)

Questa è una demo semplificata di integrazione di un assistente AI in un sistema CRM.

## Obiettivo
Simulare come un'interfaccia basata su linguaggio naturale possa essere usata per interagire con un CRM: ad esempio per ottenere dati sui clienti o generare email automatiche.

## Tecnologie
- PHP puro (no framework)
- HTML + CSS base

## Come funziona
- L’utente scrive una richiesta.
- Il sistema interpreta il testo e risponde (simulando una AI).
- Può essere esteso con OpenAI API (es. ChatGPT) o altri modelli NLP.

## Esempi di richieste
- "Mostrami i clienti attivi"
- "Genera una mail di follow-up per i clienti inattivi"

## Screenshot

![screenshot](screenshot.jpg)

## Autore
Sabino Mangano – IT Manager & AI Integrator
